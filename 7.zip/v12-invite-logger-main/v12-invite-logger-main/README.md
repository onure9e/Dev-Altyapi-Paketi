# v12-invite-logger


Altyapı Tamamıyla Elminstêr#0007 Tarafından Youtube da Paylaşılmak İçin Yapıldı!


__Youtube Kanal __  🔗 **[Youtube](https://youtube.com/channel/UCOdhrwt2fvNDTxyUxC_yxqw)**
*Altyapıyı Kullanmadan Önce Bilmeniz Gerekenler:*

**1- Altyapı Tamamıyla Elminstêr#0007 'ye aittir.**

**2- İzinsiz Paylaşılması Kesinlikle Yasaktır!**

**3- Rütbe Komutları Kanal Ayarlama Komutları İD' ile Çalışıyor!**

**4- Olası Bir Durumda Destek Sunucumuz Olan [Tıkla](https://discord.gg/4CjSpF85ca) gelebilirsiniz!**

**5- Altyapıda 'ki Her Komut Denendi Ve Çalıştığını Sağladım Bundan dolayı Bozuk veya Hatalı Komut Yoktur!**

**6- Altyapı Tamamıyla v12 dir ve sizler İçin Yapılmıştır!**

**7- Altyapıda 'ki !davet-kanal komutu !ayarlar Channel kanalid şeklinde de çalışıyor!**

**8- Daha Fazla Altyapı Gelmesini İstiyorsanız Like ve Yorum Atarak destek olabilirsiniz!**

**9- Abone Olmayı Unutmayın Canlarım [Kanal](https://youtube.com/channel/UCOdhrwt2fvNDTxyUxC_yxqw)**


