Akardiyan V12 Gelişmiş Hazır Bot Altyapı
=================
Merhaba arkadaşlar altyapı projesine hoşgeldiniz

!! => Bu kısma dikkat edin;

`ayarlar.json'dan botunuzun ayarlarını yapmazsanız bot çalışmaz`

[YouTube](https://www.youtube.com/channel/UCefQXJPxd3YxXea-W-hq5RQ)

[Discord](https://discord.gg/eyj4HbT7JH)

 
 `İyi Kullanımlar!`

