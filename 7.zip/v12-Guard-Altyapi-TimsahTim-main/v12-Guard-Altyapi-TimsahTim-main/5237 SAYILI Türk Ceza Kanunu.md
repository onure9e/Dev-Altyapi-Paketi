#   Create By TimsahTim


**5237 SAYILI Türk Ceza Kanunu**

244. MADDESİNDE DÜZENLENEN
BİLİŞİM ALANINDAKİ SUÇLAR

OFFENCES AGAINST INFORMATION SYSTEMS PRESCRIBED
UNDER ARTICLE 244 OF THE TURKISH CRIMINAL CODE


Bilişim Teknolojileri Eğitimden Ticarete, Ulaşımdan İletişime, 
Kamu Hizmetlerinden Özel Sektöre Kadar Hayatın Hemen Her Alanında Köklü Değişiklikler Yapmıştır. 

Bilişim Teknolojilerinin Bu Olumlu Yönlerine Karşı, Kötüye Kullanılması Da Kaçınılmazdır. 
Bu Sebeple Pek Çok Ülke Bilişim Alanında Yasal Düzenlemelere Gitmiş, 
Mevzuatlarını Teknolojinin Gerektirdiği Biçimde Değiştirme Çabasına Girmişlerdir.

Mukayeseli Hukuktaki Son Gelişmelere Paralel Olarak, Yeni Türk
Ceza Kanunu’nda Bilişim Suçları Bölümünde Tck’nın 244. Maddesi İle
Bilişim Sistemini Engelleme, Bozma, Verileri Yok Etme, Çalıp Değiştirme Vs. Suçu Kabul Edilmiştir.
Makalede Tck’nın 244. Maddesi Tüm Yönleriyle Açıklanmaya Çalışılacaktır.


# Guard Altyapı TimsahTim Tarafından Yapılmıştır

# Leowsu Tarafından Geliştirilmiştir

**TimsahTim'den İzinsiz İnternette Paylaşılırsa Telif Hakkı İhlali Paylaşmış Olduğunuz Altyapı Kod Silinmektedir**
**Dahada Kötüsü Biz,Ben Vs. Yaptım Deme Takdirinde İçerik Hırsızlık Sahipliğinden Dolayı Davalara Kadar Yol Açılabilir**



### Copyright © 2020 All Rights Reserved | TimsahTim