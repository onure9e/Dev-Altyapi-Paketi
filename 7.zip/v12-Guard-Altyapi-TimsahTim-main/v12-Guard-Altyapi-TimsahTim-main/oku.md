**Discord.js v12 Guard Bot Created By TimsahTim**

\\-------------------------------------------------------------------------------------------//

`✔` *TimsahTim Tarafından Yapılmış Olup ZerraFi, Ahleylim, PaganYontan, Leowsu Tarafından Geliştirilmiştir*.

`✘` *Çalınması, Kopyalanması veya Başka Sunucularda Paylaşılması Yasaktır.*

\\-------------------------------------------------------------------------------------------//

```Hata İle Karşılaştığınız Durumda Discord Sunucumuzda Destek Kanalından Talep Açabilirsiniz.```

► __Web Sitemiz;__

**• [TimsahTim Web](https://timsahtim.com/)**

► __Discord Sunucumuz;__

**• [⌭ TimsahTim](https://discord.gg/uQnkA723kU)**

\\-------------------------------------------------------------------------------------------// 

**✍ Bot Nasıl Aktif Edilir?** 

• ```Guard.json Dosyasına Gerekli Bilgileri Girdikten Sonra ```

```Botunuz Otomatik Olarak Aktif Olacaktır.```

**🤖 Bot Nasıl Yapılır?**

**1-** [DiscordDeveloper](https://discord.com/developers) ```İlk Önce Bu Siteye Giriyoruz.```

**2-** ```Discord Hesabınız İle Discord Developer'a Giriş Yapın.```

**3-** ```Application Kısmından "New Application" Seçeneğine Tıklayın.```

**4-** ```Önünüze Gelen Pencerede Botunuza Bir İsim Verin. Ben TiGuard Koydum.```

**5-** ```General İnformation Kısmından Botunuza Resim Ekleyebilirsiniz. Ben Eklemeden Geçiyorum.```

**6-** ```Sol kısımdan "Bot" Sekmesine Geliyoruz. Ardından "add Bot" Ve Onun Ardından "yes, Do İt!"```

```Seçeneğini Seçiyoruz. Botumuz Oluştu. İsterseniz Bota Da Resim Ekleyebilirsiniz.```

**💻 Discord Bot Token'i Nasıl Alınır?**

**1-** ```Botumuzu Oluşturduğumuz Yerde "bot" Sekmesine Giriyoruz Ve Karşımızda Botun İsmi, Resmi```

```Ve Token Kısımı Çıkacak. "copy" Diyerek Botun Tokenini Kopyalayabilirsiniz.```


//-------------------------------------------------------------------------------------------// 


**⚠️ #EvdeKal #MaskeTak #MesafeniKoru ⚠️**

**- TimsahTim**


**- ZerraFi, Ahleylim, PaganYontan And Leowsu**
