const Discord = require("discord.js");

module.exports = async (bot) => {

    console.log(`${bot.user.username} est prêt !`);

} 
