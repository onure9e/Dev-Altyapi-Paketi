module.exports = {
  "token": "BOTUNUZUN TOKENİ",
  "sahip": "SAHİP ID",
  "prefix": "BOTUNUZUN PREFİXİ"
};