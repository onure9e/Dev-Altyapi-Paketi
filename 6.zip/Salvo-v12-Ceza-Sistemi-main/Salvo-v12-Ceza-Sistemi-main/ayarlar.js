module.exports = {
  "token": "TOKEN",
  "sahip": "SAHİP ID",
  "prefix": "PREFİX"
};