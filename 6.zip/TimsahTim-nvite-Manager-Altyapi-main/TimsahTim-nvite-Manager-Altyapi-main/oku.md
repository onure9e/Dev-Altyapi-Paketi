**Discord.js Gezend Bot İnvite Made By DangerK**

//-------------------------------------------------------------------------------------------//

`✔` *TimsahTim Tarafından Yapılmış Olup Leowsu Tarafından Geliştirilmiştir*.

`✘` *Çalınması, Kopyalanması veya Başka Sunucularda Paylaşılması Yasaktır.*

//-------------------------------------------------------------------------------------------//

```Hata İle Karşılaştığınız Durumda Discord Sunucumuzda Destek Kanalından Talep Açabilirsiniz.```

► __Web Sitemiz;__

**• [TimsahTim Web](https://timsahtim.com/)**

► __Discord Sunucumuz;__

**• [⌭ TimsahTim](https://discord.gg/XpHPcbPdW7)**

//-------------------------------------------------------------------------------------------// 

**✍ Bot Nasıl Aktif Edilir?** 

• ```ayarlar.json dosyasına gerekli bilgileri girdikten sonra ```

```botunuz otomatik olarak aktif olacaktır.```

**🤖 Bot Nasıl Yapılır?**

**1-** [DiscordDeveloper](https://discord.com/developers) ```ilk önce bu siteye giriyoruz.```

**2-** ```Discord hesabınız ile Discord Developer'a giriş yapın.```

**3-** ```Application kısmından "New Application" seçeneğine tıklayın.```

**4-** ```Önünüze gelen pencerede botunuza bir isim verin. Ben Pink Code koydum.```

**5-** ```General İnformation kısmından botunuza resim ekleyebilirsiniz. Ben eklemeden geçiyorum.```

**6-** ```Sol kısımdan "Bot" sekmesine geliyoruz. Ardından "Add Bot" ve onun ardından "Yes, do it!"```

```seçeneğini seçiyoruz. Botumuz oluştu. İsterseniz bota da resim ekleyebilirsiniz.```

**💻 Discord Bot Token'i Nasıl Alınır?**

**1-** ```Botumuzu oluşturduğumuz yerde "Bot" sekmesine giriyoruz ve karşımızda botun ismi, resmi```

```ve token kısımı çıkacak. "Copy" diyerek botun tokenini kopyalayabilirsiniz.```

**📹 Youtube Api Key v3 Nasıl Alınır?**

**1-** [GoogleDeveloper](https://console.developers.google.com/apis/api/youtube.googleapis.com/overview?project=balmy-ocean-281816) ```ilk önce bu siteye giriyoruz.```

**2-** ```Google hesabınız ile Google Developer'a giriş yapın.```

**3-** ```Sağ üstte "Kimlik bilgileri oluştur" seçeneğine tıklayın.```

**4-** ```"Hangi Api'yi kullanıyorsunuz?" sorusuna "Youtube Data Api v3" olarak cevap verin.```

**5-** ```"API'yi nereden çağıracaksınız?" sorusuna "Web Tarayıcısı (JavaScript)" olarak cevap verin.```

**6-** ```"Hangi verileri işleyeceksiniz?" sorusuna "Herkese açık veriler" olarak cevap verin.```

**7-** ```Ardından mavi butona tıklayın ve karşınıza kimlik bilgileri çıkacak. Bunları kısıtlamadan kullanmayın. Yoksa botunuz sorun çıkartabilir.```


**📱 Youtube Api Key v3 Nasıl Kısıtlandırılır?**

**1-** ```Api key'i aldıktan sonra kimlik bilgileri geldiğinde aşağıda "Anahtarı Kısıtlayın." diye seçenek vardır. Tıklayın.```


**2-** ```Sizi Bir Sayfaya Yönlendirecektir.```

**3-** ```Yönlendirildiğiniz Sayfada "Api Kısıtlamaları" Bölümünden "Youtube Data Api v3"ü Seçin.```

**4-** ```Kaydet Dedikten Sonra Api Anahtar'ınızın Kısıtlanması 5 ila 10 Dakikayı Bulabilir. Sabrederek Bekleyin.```

//-------------------------------------------------------------------------------------------// 


**⚠️ #EvdeKal #MaskeTak #MesafeniKoru ⚠️**

**- TimsahTim**


**- Motion and Leowsu**
