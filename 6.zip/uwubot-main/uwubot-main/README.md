------------------------------------------------------------------------------
# UwU Bot 
------------------------------------------------------------------------------
[![Discord Bots](https://discordbots.org/api/widget/797803769801736192.svg)](https://discordbots.org/bot/797803769801736192)
------------------------------------------------------------------------------
# ENGLISH README.md:
------------------------------------------------------------------------------
 - UwU Bot with lots of nice commands!
 - It's free, fill in botconfig/config.json!
 - Everything is set!
 - It works with the prefix you set! It has a premium system!
------------------------------------------------------------------------------
#### Made by: `ArchéxKaan`, `ArchéxMelih`
#### YouTube channels: **[ArchéxKaan](https://www.youtube.com/channel/UC9HFT7vVnIgf_w9kr41OIuA)**, **[ArchéxMelih](https://www.youtube.com/ArchéxMelih)**
#### Discord server: **[click!](https://discord.gg/MgmHyg7Gfu)**
------------------------------------------------------------------------------
# TÜRKÇE README.md:
------------------------------------------------------------------------------
 - Çok sayıda güzel komut içeren UwU Bot!
 - Ücretsizdir, botconfig/config.json'u doldurun!
 - Her şey hazır!
 - Belirlediğiniz önek ile çalışır! Premium bir sistemi var!
------------------------------------------------------------------------------
#### Yapımcılar: `ArchéxKaan`, `ArchéxMelih`
#### YouTube kanallarımız: **[ArchéxKaan](https://www.youtube.com/channel/UC9HFT7vVnIgf_w9kr41OIuA)**, **[ArchéxMelih](https://www.youtube.com/ArchéxMelih)**
#### Discord sunucumuz: **[tıkla!](https://discord.gg/MgmHyg7Gfu)**
------------------------------------------------------------------------------
