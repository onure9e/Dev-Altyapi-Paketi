# Discord Server List

Bu websitesi TheClawNz#7987 tarafından yapılmıştır, ücretli bir şekilde verilmesi yasaktır sunucunuzda paylaşıcaksanız eğer açıklama kısımına https://discord.gg/AJ4fzBsuSq koymanız yeterlidir.

# Kurulum

Modüllerin yüklenmesi için öncelikle <code>npm install</code> yazınız,
ardından <code>index.js</code> adlı dosyaya girip en aşağıya botunuzun tokenini girin,
ardından <code>app.js</code> adlı dosyaya girip en üst kısımda bulunan <code>oauthSecret</code> kısmına botunuzun oauth secretini giriniz, sonrasında <code>callbackURL</code> yazan yere botunuzun callback urlsini yazın (Örnek: https://blabla.com/callback), ardından <code>domain</code> yazan yere websitenizin urlsini yazın.

# Yapılacaklar

• Sunucu Düzenleme: ✅<br>
• Ses Sıralama: ❌<br>
• Admin Panel: ✅<br>
• Şikayet Sistemi: ❌<br>
• Profil Düzenleme: ✅<br>
• 404 Sayfası: ✅<br>
• Oy Sistemi: ✅<br>
• Sertifika Sistemi: ✅<br>
• Yorum Sistemi: ❌<br>
• Karaliste Sistemi: ❌<br>
• Flash Messages: ❌

# Proje Bilgileri

• Yayınlanma Tarihi: 23.4.2021 - 01:33<br>
• Başlangıç Tarihi: 18.4.2021 - 20:00<br>
• Proje Sahibi: TheClawNz#7987<br>
• Yardımcılar: NullMan#4807
