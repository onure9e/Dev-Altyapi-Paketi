const Discord = require("discord.js");
const superagent = require("superagent");

exports.run = (client, msg, args) => {
  if (msg.channel.nsfw === true) {
    superagent
      .get("https://nekobot.xyz/api/image")
      .query({ type: "pgif" })
      .end((err, response) => {
        msg.channel.send({ file: response.body.message });
      });
  } else {
    msg.channel.send(
      "Bu kanal bir NSFW kanalı değil! Nasıl Yapılır Metin kanalının ustune gelip kanalı düzenle yerine girin ordan asagı inin uygunsuzkanalı açın"
    );
  }
};

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: "nsfw",
  description: "nsfw Komut",
  usage: "nsfw"
};
