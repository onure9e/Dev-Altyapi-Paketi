<img src="https://cdn.discordapp.com/attachments/784328192189530133/787441693997268992/Selampak.png">

`Alın kullanın v11 ama olsun bot işlerinde amatördüm o zamanlarda yapmıştım `

**Kullan**

-Selçuk#8730 -- DİSCORD İSMİM


