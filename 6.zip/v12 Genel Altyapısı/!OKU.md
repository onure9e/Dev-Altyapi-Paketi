![](https://i.hizliresim.com/MtAXOY.png)

Loz 'Bey v12 Temiz ALTYAPIDIR.
--