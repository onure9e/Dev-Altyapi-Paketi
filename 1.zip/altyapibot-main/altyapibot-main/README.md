Bu Altyapı Mustafa Yılmaza Aittir Altyapıyı Kullanmak İçin Benden İzin Alınız Altyapıyı Çok Emek Vererek Yaptım O Yüzden Kanalıma Abone Olmayı Unutmayın.

Kanalım:http://bit.ly/3q3kxEN

Herhangi Bir Hata Olursa Discordum(Sınırsız Link):http://bit.ly/3tyu9cF
