Merhaba Ben ByCanerX Official

 Bu Alt Yapı Nereden Aldığımı Gizliyorum Kusuruma Bakmayın Alt Yapı Benim Elime Geçtiğinde İngilizce iDİ Komple Türkçeleştirdim
 Görmediğim Bir yer Varsa Google Çeviriden Çevirebilirsiniz
 İyi Kullanımlar.


CnrX BOT Müzik BOT Alt Yapısı ByCanerX Tarafından Türkçe Çevrilmiş Ve Türk Milletine Sunulmuştur.


[Discord Sunucum](https://discord.gg/4hVNHxWjn3)

[Youtube kanalım](https://www.youtube.com/channel/UCldl8ajYEJXAcKn6XftoX3Q)