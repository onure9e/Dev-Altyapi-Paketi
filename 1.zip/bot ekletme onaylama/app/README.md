Bot Ekletme Botu

