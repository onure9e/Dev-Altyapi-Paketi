const config = {
  "token": "Njg4NjY2NzA4OTMxNjQxMzU5.XnYieQ.CUh8qhsLiRGMtOVbgn2GMI4Lj9g",
  "sahip": "681872205193150488",
 
  "dashboard" : {
    "oauthSecret": "d6X5td5SSYMEAEwsMOCxJXNZnbYPdlsm",//Botun Secretini Girdin Mi Buraya  evet girmd
    "callbackURL": "https://mcsda.glitch.me//callback",
  "sessionSecret": "d6X5td5SSYMEAEwsMOCxJXNZnbYPdlsm",
    "domain": "https://mcsda.glitch.me/",
    "port": 8000
  },
};

module.exports = config;