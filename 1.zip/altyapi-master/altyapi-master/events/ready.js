const chalk = require('chalk');
const moment = require('moment');
const Discord = require('discord.js');
const ayarlar = require('../ayarlar.js');

var prefix = ayarlar.prefix;

module.exports = client => {
console.log('>> Oynuyor kısmı başarıyla güncellendi. <<');
console.log(`${prefix}yardım + ${client.guilds.size} sunucu + ${client.users.size} kullanıcı`);
console.log('>> Bot Hazır Giriş Yapıldı Ve BrTritan_TF Altyapılı Bot Aktif Edildi! <<');
client.user.setGame('BrTritan_TF Altyapı Aktif!', `https://www.twitch.tv/BrTritan_TF`)
}; 