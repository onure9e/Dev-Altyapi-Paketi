# BrTritan_TF#4929 Bot Altyapı
Bu Altyapı BrTritan_TF#4929 Tarafından Tasarlanıp Halka Açık Halde Sunulmuştur. Kullanabilirsiniz

Kurulum cmd
1. Kurulum için gereken programlar:
Node.JS
Git
Programlarımızı kurduktan sonra, Dosyayi Indiriyoruz.
Dosyalarımız indikten sonra ayarlar.js dosyasını ayarlıyoruz ve node bot.js komutu ile botumuzu çalıştırıyoruz.

Kurulum Glitch
Kurulum İçin Program Gerekmemektedir:
Altyapıyı Glitch Projenize Yükledikten Sonra Consola pnpm i Yazarak Modülleri Yükleyebilirsiniz