const Discord = require("discord.js"); //modüller

exports.run = async (client, message, args) => { //başlangıç
   
} //bitiş

exports.conf = { 
  enabled: true, //komut aktifmi
  guildOnly: false, //sadece sunucuda kullanılsın 
  aliases: [], //kısaltmalar
  permLevel: 0 //yetki seviyesi
};

exports.help = {
  name: '', //komut ismi
  description: '', //açıklama
  usage: '' //kullanımı
};
