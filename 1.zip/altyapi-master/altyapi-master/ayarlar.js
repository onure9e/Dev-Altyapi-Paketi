const ayarlar = {
  "sahip": "", //kendi IDınızı yazınız
  "geliştirici": [""],
  "destekçi": [""],
  "token": "", //botunuzun tokenini yazınız
  "prefix": "", //botunuzun prefixini yazınız
};

module.exports = ayarlar;