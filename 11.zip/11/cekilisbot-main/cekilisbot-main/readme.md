ayarlar.json da ki 
everyoneMention kısmını TRUE yaparsanız çekiliş başladığında bot everyone çeker