# Code BY

     #Crew Code
     #Narcoz Code

Crew Code [**Discord Sunucumuza Katıl**](https://discord.gg/XTsKVQSgpG)

Crew Code [**Youtube kanalımı takip etmeyi unutmayın!**](https://www.youtube.com/channel/UCFWkgTpLpQAsvaEi-YwpPig?view_as=subscriber)

Narcos Code [**Discord Sunucumuza Katıl**](https://discord.gg/d7nnBN4Jn8)

Narcos code [**Youtube kanalımı takip etmeyi unutmayın!**](https://www.youtube.com/channel/UCD9s0x7OrF3XPmmV7AlBrhA)

     bu alt yapı narcos code ve crew code tarafından kodlanmıştır 9.12.2020
     tarihinde yayınlanmıştır aksini idda edenin taaaa...
