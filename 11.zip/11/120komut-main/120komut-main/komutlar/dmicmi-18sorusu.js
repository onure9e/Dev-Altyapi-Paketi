const Discord = require("discord.js");
const tinkiepink = [
    "Seni en çok ne tahrik eder?",
    "Hiç ayna ile öpüşmeye çalıştın mı?",
    "Vücudunla ilgili bir şeyi değiştirebilecek olsan bu ne olurdu?",
    "Okulunda başka bir kızın yerine geçecek olsan kim olurdun?",
    "Bir gün boyunca sutyenini tişörtünün dışında giymen için sana 5.000 TL verilse bunu kabul eder miydin?",
    "Çirkin ama yatakta iyi olan biriyle mi yoksa güzel ama yatakta kötü olan biriyle mi çıkmak isterdin?",
    "Burada yer alan kişilerden kimle çıkmak istersin?",
    "Kardeşinin kız arkadaşıyla çıkabilecek olsaydın bu kim olurdu?",
    "Sarışınlar mı yoksa esmerler mi?",
    "Bir geceliğine yatağını en yakın arkadaşının sevgilisiyle paylaşır mısın?",
    "Bir günlüğüne karşı cins olsan ne yapardın?",
    "Kaç tane çocuk sahibi olmak istersiniz?",
    "Çıplak kalmak veya aklından geçenlerin kafanın üstünde yazması arasında bir seçim yapmak zorunda olsan hangisini seçerdin?",
    "Hiç cinsel yolla bulaşan bir hastalığın oldu mu?",
    "Çekici olduğunu düşündüğün bir öğretmenin oldu mu hiç? Kim? Neden?",
    "En kötü öpüşmen hangisiydi?",
    "İlk kiminle öpüştün?",
    "İlk buluşmada karşındaki çocuğu öper misin?",
    "Hiç en iyi arkadaşının erkek kardeşiyle flört ettin mi?",
    "Hiç erkek arkadaşını/kız arkadaşını aldatmayı düşündün mü?",
    "Hiç arkadaşının erkek arkadaşına aşık oldun mu?",
    "Bir erkekle ilgili en seksi şey nedir?",
    "Bir kızla ilgili en seksi şey nedir?",
    "Hiç sevgilini aldattın mı?",
    ];

exports.run = async(client , message, args) =>{
    let tinkie = tinkiepink[Math.floor(Math.random() * tinkiepink.length)]; 
    const pinkcode = new Discord.MessageEmbed()
    .setColor("BLACK")
    .setTitle(`*${tinkie}*`)
    .setDescription(`**__Lütfen +18 Soruyu Cevaplayınız__**`)
    .setAuthor(`${message.author.tag}`)
    .setThumbnail(`${message.author.avatarURL()}`)

    message.channel.send(pinkcode)
}

exports.conf ={
    "aliases": ["18", "artı18"],
    "permLevel": "0"
}

exports.help = {
    "name": "+18",
    "description": "+18",
    "usage": ".18"
}